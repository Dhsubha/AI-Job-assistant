# AI Job Assistant India

An Android MVP for Indian job seekers, with English, Bengali and Hindi interfaces.

## Working in this source package
- Native Android app built with Kotlin and Jetpack Compose
- Language selector: English / বাংলা / हिन्दी
- Firebase Authentication helpers for anonymous guest and Google sign-in
- Profile creation/update in Cloud Firestore after sign-in
- Resume draft builder with education, skills and experience fields
- Cover-letter draft builder
- Interview practice questions and personal notes
- Save resume, cover-letter and interview drafts to the signed-in user's private Firestore path
- Workplace English phrases and basic career guidance
- Firestore owner-only security rules

## Important limitations
This is an MVP source project, not a released APK. The resume and cover-letter tools currently use local templates; live AI generation is **not connected**. The backend starter is included separately and requires deployment plus a server-side Gemini API key. Do not put an AI API key in the Android app.

Google sign-in requires the correct SHA-1/SHA-256 signing fingerprints and an Android OAuth client for package `in.aijobassistant` in Firebase/Google Cloud. The supplied `google-services.json` has the matching package and project, but its OAuth entries still need to be checked after adding your signing certificate. Guest sign-in requires Anonymous Authentication to be enabled.

Cloud draft saving requires a Firestore database to be created and `firestore.rules` deployed. Firebase has not been remotely changed by this package.

## Open and run
1. Install Android Studio and the Android SDK (API 35).
2. Open the `android/` folder in Android Studio.
3. Allow Gradle sync. If Android Studio asks for a Gradle distribution, use Gradle 8.11.1 or the version recommended by the IDE for Android Gradle Plugin 8.9.2.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Run the `app` configuration.

## Firebase setup
1. Confirm the Firebase project ID is `gen-lang-client-0393857895` and Android package is `in.aijobassistant`.
2. In Firebase Authentication, enable Anonymous and Google providers.
3. Add the SHA-1 and SHA-256 fingerprints for the signing key used to run the app. For a local debug key, Android Studio's Gradle `signingReport` task shows them.
4. Download the refreshed `google-services.json` and place it at `android/app/google-services.json`.
5. Create the Cloud Firestore database.
6. From the repository root, install Firebase CLI, sign in, select the project, then deploy: `firebase deploy --only firestore:rules,firestore:indexes`.

## Security and release checklist
- Firebase `google-services.json` is client configuration, not a service-account credential; restrict its API key to the Android app where practical. Never commit service-account JSON, private signing keys or AI provider keys.
- Deploy the AI backend behind Firebase ID-token verification and request rate limits before enabling AI features.
- Add a privacy policy, consent flow, data deletion controls, accessibility checks and production monitoring.
- Test authentication and Firestore rules on a real device before Play Store release.
- Never claim a generated resume guarantees an interview or job. Users must verify every detail.
