# Firebase and AI backend setup

## Firebase project
1. Create a Firebase project in the Firebase console.
2. Add Android app package `in.aijobassistant`.
3. Download `google-services.json` into `android/app/` (do not commit it).
4. Enable Authentication providers: Anonymous and Google.
5. For Google sign-in, add the SHA-1 and SHA-256 fingerprints for debug and release signing certificates in Firebase.
6. Add Firebase Auth SDK and Google Services Gradle plugin using the current Firebase Android setup instructions. The exact Gradle versions should be taken from Firebase's current documentation when wiring the project.

## Guest-to-Google account upgrade
When a guest decides to register, prefer linking the Google credential to the existing anonymous Firebase user (`currentUser.linkWithCredential(credential)`) rather than signing into a separate account. This preserves the guest UID and any associated data. Handle `FirebaseAuthUserCollisionException` by offering an account-merge flow.

## Backend identity
- For local development, use Application Default Credentials with a Firebase service account.
- In production, use the hosting platform's workload identity/service account. Do not bake service-account JSON into the container or Android app.
- The API verifies Firebase ID tokens and revocation status before processing.

## AI provider
The starter calls the Gemini REST API server-side. Set `GEMINI_API_KEY` as a managed server secret. The configured model is controlled by `GEMINI_MODEL`. Check current model availability, free-tier eligibility, regional restrictions, rate limits and terms before deployment. Do not assume unlimited free usage.

## Deployment
Deploy the backend to a managed HTTPS service such as Cloud Run, configure environment secrets and health checks, and set a maximum instance count / budget alerts. For production, replace the in-memory limiter with a shared store and consider Firebase App Check / Play Integrity.

## Data protection
The current API does not persist CV text. Avoid logging user prompts or resumes. Publish a privacy policy explaining authentication, AI processing, retention, deletion and third-party processors before public launch.

## Finish Android Firebase Gradle wiring
Apply the Google Services Gradle plugin in the root and app Gradle files using the current version from Firebase's setup guide, then sync Gradle. The `google-services.json` file is intentionally excluded from this starter. Firebase configuration is project-specific and must come from your own Firebase console.
