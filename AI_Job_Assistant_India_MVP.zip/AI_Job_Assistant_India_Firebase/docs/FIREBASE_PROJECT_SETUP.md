# Connect AI Job Assistant India to your existing Firebase project

Target Firebase project ID: `gen-lang-client-0393857895`
Android application ID / package: `in.aijobassistant`
App display name: `AI Job Assistant India`

## Important access limitation
The available connected tools in this chat do not include Firebase Console/Admin/CLI actions. Therefore I have prepared the code and rules, but I cannot truthfully claim that I registered the Android app in your Firebase project, enabled providers, created Firestore, or downloaded your project-specific `google-services.json`. Those actions must be completed in the Firebase Console or Firebase CLI using an account with access to the project.

## Register the Android app
1. Open https://console.firebase.google.com/project/gen-lang-client-0393857895/overview
2. Confirm the project ID shown is exactly `gen-lang-client-0393857895`.
3. Click the Android icon / Add app.
4. Android package name: `in.aijobassistant` (case-sensitive; this cannot be changed for this Firebase app after registration).
5. App nickname: `AI Job Assistant India`.
6. Register the app.
7. Download `google-services.json`.
8. Place it at `android/app/google-services.json` in this project. Do not rename it or commit it to a public repository.

## Enable Firebase Authentication
1. Open Authentication > Sign-in method / Providers.
2. Enable Google. Select a support email if asked, then save.
3. Enable Anonymous sign-in for guest mode.
4. In Project settings > Your apps > Android app, add SHA-1 and SHA-256 fingerprints for debug and release signing keys.
5. Download a fresh `google-services.json` after configuring Google sign-in and replace the old file.

Google sign-in uses Credential Manager and the Firebase GoogleAuthProvider flow in `FirebaseSignIn.kt`. Guest-to-Google account linking is provided so a guest can keep the same Firebase UID and drafts after registering.

## Enable Cloud Firestore
1. Open Firestore Database > Create database.
2. Choose Production mode.
3. Select a location close to your users and compatible with your data residency requirements. Firestore database location is difficult to change later.
4. Create the database.
5. From the project root, deploy the included rules and indexes using Firebase CLI:
   `firebase use gen-lang-client-0393857895`
   `firebase deploy --only firestore:rules,firestore:indexes`
6. Review the rules before deploying. They allow only an authenticated user to access their own `/users/{uid}` profile and nested drafts.

## Android Studio
1. Open the `android/` folder in Android Studio.
2. Put your downloaded config file at `android/app/google-services.json`.
3. Sync Gradle.
4. Run on a device/emulator with Google Play services.
5. Test anonymous sign-in, Google sign-in, profile write, draft save, draft list and delete.

## SHA fingerprints
From the Android project folder:
- Debug SHA-1: `./gradlew signingReport` (Windows: `gradlew signingReport`)
- Copy SHA-1 and SHA-256 from the debug variant into Firebase Console.
- Add release fingerprints before Play Store release.

## Firestore data structure
- `users/{uid}` — profile fields and preferred language.
- `users/{uid}/drafts/{draftId}` — user-owned resume, cover letter and interview notes.

The starter repository saves drafts only when the user explicitly requests it. Do not store CVs or personal data without clear user consent.

## Backend identity
The backend verifies Firebase ID tokens using Firebase Admin SDK. For deployment, configure its service identity with permission to verify Firebase users. Never put service-account JSON or AI provider keys in the Android app or a public Git repository.
