package in.aijobassistant

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * User-owned data only. Firestore rules enforce that each user can access
 * documents under their own UID. Avoid saving sensitive CV data without consent.
 */
class FirestoreRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun uid(): String = auth.currentUser?.uid ?: error("Please sign in first.")

    suspend fun createOrUpdateProfile(
        displayName: String?,
        email: String?,
        preferredLanguage: String
    ) {
        require(preferredLanguage in setOf("en", "bn", "hi"))
        val userId = uid()
        val values = mapOf(
            "uid" to userId,
            "displayName" to displayName,
            "email" to email,
            "preferredLanguage" to preferredLanguage,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("users").document(userId).set(values).await()
    }

    suspend fun saveDraft(
        type: String,
        title: String,
        content: String,
        language: String
    ): String {
        require(type in setOf("resume", "cover-letter", "interview-notes"))
        require(language in setOf("en", "bn", "hi"))
        require(title.length <= 120 && content.length <= 20000)
        val userId = uid()
        val data = mapOf(
            "ownerUid" to userId,
            "type" to type,
            "title" to title,
            "content" to content,
            "language" to language,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return db.collection("users").document(userId)
            .collection("drafts").add(data).await().id
    }

    suspend fun listDrafts() =
        db.collection("users").document(uid()).collection("drafts")
            .orderBy("updatedAt")
            .get().await()

    suspend fun deleteDraft(draftId: String) {
        db.collection("users").document(uid())
            .collection("drafts").document(draftId).delete().await()
    }
}
