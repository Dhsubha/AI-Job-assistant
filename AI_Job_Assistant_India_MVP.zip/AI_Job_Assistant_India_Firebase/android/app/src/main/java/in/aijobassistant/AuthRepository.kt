package in.aijobassistant

import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await

/**
 * Guest mode is implemented here. For Google sign-in, obtain an ID-token
 * credential with Android Credential Manager, then call signInWithGoogleIdToken.
 */
class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    suspend fun continueAsGuest() = auth.signInAnonymously().await()

    suspend fun signInWithGoogleCredential(credential: AuthCredential) =
        auth.signInWithCredential(credential).await()

    suspend fun getBackendIdToken(): String {
        val user = auth.currentUser ?: error("Please sign in first.")
        return user.getIdToken(false).await().token
            ?: error("Could not obtain a secure session token.")
    }

    fun isGuest(): Boolean = auth.currentUser?.isAnonymous == true

    fun signOut() = auth.signOut()
}
