package in.aijobassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private enum class Lang { EN, BN, HI }
private data class Copy(val title:String, val subtitle:String, val resume:String, val interview:String,
                        val cover:String, val english:String, val guidance:String, val name:String,
                        val role:String, val generate:String, val result:String, val back:String)

private fun copyFor(lang: Lang) = when(lang) {
    Lang.BN -> Copy("AI Job Assistant","আপনার ক্যারিয়ারের পরবর্তী পদক্ষেপ","AI রিজিউম বিল্ডার","ইন্টারভিউ প্রস্তুতি",
        "কভার লেটার","ইংরেজি অনুশীলন","ক্যারিয়ার গাইডেন্স","আপনার নাম","যে পদের জন্য আবেদন করবেন","তৈরি করুন","আপনার খসড়া","ফিরে যান")
    Lang.HI -> Copy("AI Job Assistant","आपके करियर का अगला कदम","AI रिज़्यूमे बिल्डर","इंटरव्यू तैयारी",
        "कवर लेटर","अंग्रेज़ी अभ्यास","करियर मार्गदर्शन","आपका नाम","किस पद के लिए आवेदन करेंगे","बनाएं","आपका ड्राफ्ट","वापस")
    else -> Copy("AI Job Assistant","Your next career move starts here","AI Resume Builder","Interview Practice",
        "Cover Letter","English Practice","Career Guidance","Your name","Target job role","Generate","Your draft","Back")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(activity = this) }
    }
}

@Composable
private fun App(activity: ComponentActivity) {
    val auth = remember { FirebaseSignIn(activity) }
    val firestore = remember { FirestoreRepository() }
    val scope = rememberCoroutineScope()
    var accountLabel by remember { mutableStateOf(auth.currentUser()?.let { if (it.isAnonymous) "Guest account" else (it.email ?: "Google account") } ?: "Not signed in") }
    var authMessage by remember { mutableStateOf("") }
    var authBusy by remember { mutableStateOf(false) }
    var lang by remember { mutableStateOf(Lang.EN) }
    var page by remember { mutableStateOf("home") }
    var person by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var education by remember { mutableStateOf("") }
    var skills by remember { mutableStateOf("") }
    var experience by remember { mutableStateOf("") }
    var interviewNotes by remember { mutableStateOf("") }
    var saveBusy by remember { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf("") }
    var savedDrafts by remember { mutableStateOf<List<Triple<String, String, String>>>(emptyList()) }
    var draftsLoading by remember { mutableStateOf(false) }
    val c = copyFor(lang)
    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF4F46E5),
        secondary = androidx.compose.ui.graphics.Color(0xFF0F766E),
        background = androidx.compose.ui.graphics.Color(0xFFF7F8FC)
    )) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("✦ CAREER COMPANION", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { expanded = true }) { Text(when(lang){Lang.BN->"বাংলা";Lang.HI->"हिन्दी";else->"English"}) }
                        DropdownMenu(expanded, { expanded = false }) {
                            DropdownMenuItem(text={Text("English")}, onClick={ {lang=Lang.EN;expanded=false} })
                            DropdownMenuItem(text={Text("বাংলা")}, onClick={ {lang=Lang.BN;expanded=false} })
                            DropdownMenuItem(text={Text("हिन्दी")}, onClick={ {lang=Lang.HI;expanded=false} })
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                if (page == "home") {
                    Text(c.title, style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.Bold)
                    Text(c.subtitle, style=MaterialTheme.typography.bodyLarge, color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(22.dp))
                    Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primary), shape=RoundedCornerShape(24.dp)) {
                        Column(Modifier.padding(22.dp)) {
                            Text("✨ AI CAREER TOOLS", color=androidx.compose.ui.graphics.Color.White, style=MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.height(8.dp))
                            Text("Build skills. Prepare confidently. Move forward.", color=androidx.compose.ui.graphics.Color.White,
                                style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("A simple toolkit for students, freshers and job seekers across India.",
                                color=androidx.compose.ui.graphics.Color.White.copy(alpha=.9f))
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Account", fontWeight=FontWeight.Bold, style=MaterialTheme.typography.titleMedium)
                            Text(accountLabel, color=MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                Button(enabled=!authBusy, onClick={
                                    scope.launch {
                                        authBusy = true; authMessage = ""
                                        try {
                                            val user = auth.continueAsGuest()
                                            firestore.createOrUpdateProfile(user.displayName, user.email, when(lang){Lang.BN->"bn";Lang.HI->"hi";else->"en"})
                                            accountLabel = "Guest account"; authMessage = "Guest sign-in successful."
                                        } catch (e: Exception) { authMessage = e.localizedMessage ?: "Sign-in failed." }
                                        authBusy = false
                                    }
                                }) { Text("Continue as Guest") }
                                OutlinedButton(enabled=!authBusy, onClick={
                                    scope.launch {
                                        authBusy = true; authMessage = ""
                                        try {
                                            val user = auth.signInWithGoogle()
                                            firestore.createOrUpdateProfile(user.displayName, user.email, when(lang){Lang.BN->"bn";Lang.HI->"hi";else->"en"})
                                            accountLabel = user.email ?: "Google account"; authMessage = "Google sign-in successful."
                                        } catch (e: Exception) { authMessage = e.localizedMessage ?: "Google sign-in failed." }
                                        authBusy = false
                                    }
                                }) { Text("Continue with Google") }
                            }
                            if (authBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
                            if (authMessage.isNotBlank()) Text(authMessage, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    ToolCard("📄", c.resume, "Create a clear, job-focused resume") { page="resume" }
                    ToolCard("🎤", c.interview, "Practice common HR and role-based questions") { page="interview" }
                    ToolCard("✉️", c.cover, "Draft a tailored application letter") { page="cover" }
                    ToolCard("🌐", c.english, "Practice useful workplace English") { page="english" }
                    ToolCard("🧭", c.guidance, "Explore skills and career pathways") { page="guidance" }
                    ToolCard("📚", "My Saved Drafts", "View or delete drafts saved to your account") {
                        if (auth.currentUser() == null) {
                            authMessage = "Please sign in first to view saved drafts."
                        } else {
                            page = "saved"
                            scope.launch {
                                draftsLoading = true
                                try {
                                    savedDrafts = firestore.listDrafts().documents.map { doc ->
                                        Triple(doc.id, doc.getString("title") ?: "Untitled draft", doc.getString("content") ?: "")
                                    }
                                } catch (e: Exception) { saveMessage = e.localizedMessage ?: "Could not load drafts." }
                                draftsLoading = false
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Early preview • AI services are not connected yet", style=MaterialTheme.typography.bodySmall,
                        color=MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    TextButton(onClick={page="home"}) { Text("← ${c.back}") }
                    Text(when(page){"resume"->c.resume;"interview"->c.interview;"cover"->c.cover;"english"->c.english;"saved"->"My Saved Drafts";else->c.guidance},
                        style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    when(page) {
                        "saved" -> {
                            if (draftsLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                            if (savedDrafts.isEmpty() && !draftsLoading) Text("No saved drafts yet. Create a resume or cover letter and save it here.")
                            savedDrafts.forEach { draft ->
                                Card(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(draft.second, fontWeight=FontWeight.Bold)
                                        Spacer(Modifier.height(6.dp))
                                        Text(draft.third, maxLines=8)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedButton(enabled=!saveBusy, onClick={
                                            scope.launch {
                                                saveBusy = true
                                                try {
                                                    firestore.deleteDraft(draft.first)
                                                    savedDrafts = savedDrafts.filterNot { it.first == draft.first }
                                                } catch (e: Exception) { saveMessage = e.localizedMessage ?: "Could not delete draft." }
                                                saveBusy = false
                                            }
                                        }) { Text("Delete draft") }
                                    }
                                }
                            }
                            if (saveMessage.isNotBlank()) Text(saveMessage, color=MaterialTheme.colorScheme.primary)
                        }
                        "resume","cover" -> {
                            OutlinedTextField(person,{person=it},label={Text(c.name)},modifier=Modifier.fillMaxWidth())
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(role,{role=it},label={Text(c.role)},modifier=Modifier.fillMaxWidth())
                            if (page == "resume") {
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(education,{education=it},label={Text("Education / qualification")},modifier=Modifier.fillMaxWidth(), minLines=2)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(skills,{skills=it},label={Text("Skills (comma separated)")},modifier=Modifier.fillMaxWidth(), minLines=2)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(experience,{experience=it},label={Text("Experience / projects")},modifier=Modifier.fillMaxWidth(), minLines=2)
                            }
                            Spacer(Modifier.height(14.dp))
                            Button(onClick={
                                saveMessage = ""
                                output = if(page=="resume")
                                    "RESUME DRAFT\n${person.ifBlank{"Your Name"}}\nTarget role: ${role.ifBlank{"Not specified"}}\n\nPROFESSIONAL SUMMARY\nMotivated candidate seeking an opportunity as ${role.ifBlank{"this role"}}. Adapt this summary to your real experience and strengths.\n\nKEY SKILLS\n${skills.ifBlank{"Add your relevant skills"}}\n\nEXPERIENCE / PROJECTS\n${experience.ifBlank{"Add your work experience, internship or projects"}}\n\nEDUCATION\n${education.ifBlank{"Add your qualification and institution"}}\n\nPlease verify every detail before applying."
                                else "Dear Hiring Manager,\n\nI am writing to apply for ${role.ifBlank{"the advertised position"}}. My name is ${person.ifBlank{"[Your Name]"}}. I am eager to contribute my skills and learn with your team.\n\nThank you for your consideration.\n\nSincerely,\n${person.ifBlank{"[Your Name]"}}"
                            }, modifier=Modifier.fillMaxWidth()) { Text(c.generate) }
                            if(output.isNotBlank()) {
                                Spacer(Modifier.height(16.dp))
                                Card { Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                    Text(c.result, fontWeight=FontWeight.Bold)
                                    Spacer(Modifier.height(8.dp))
                                    Text(output)
                                    Spacer(Modifier.height(12.dp))
                                    Button(enabled = !saveBusy && auth.currentUser() != null, onClick = {
                                        scope.launch {
                                            saveBusy = true; saveMessage = ""
                                            try {
                                                val type = if (page == "resume") "resume" else "cover-letter"
                                                val title = if (page == "resume") "Resume - ${person.ifBlank { "My profile" }}" else "Cover letter - ${role.ifBlank { "Job application" }}"
                                                firestore.saveDraft(type, title, output, when(lang){Lang.BN->"bn";Lang.HI->"hi";else->"en"})
                                                saveMessage = "Saved securely to your account."
                                            } catch (e: Exception) { saveMessage = e.localizedMessage ?: "Could not save draft." }
                                            saveBusy = false
                                        }
                                    }) { Text(if (saveBusy) "Saving…" else "Save draft to my account") }
                                    if (saveMessage.isNotBlank()) Text(saveMessage, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.primary)
                                } }
                            }
                        }
                        "interview" -> {
                            Text("Practice these starter questions:", fontWeight=FontWeight.SemiBold)
                            listOf("Tell me about yourself.","Why should we hire you?","What are your strengths?","Describe a challenge you solved.","Where do you see yourself in three years?").forEachIndexed { i,q ->
                                Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) { Text("${i+1}. $q", Modifier.padding(16.dp)) }
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(interviewNotes,{interviewNotes=it},label={Text("Write your practice answers / notes")},modifier=Modifier.fillMaxWidth(), minLines=4)
                            Button(enabled = !saveBusy && auth.currentUser() != null && interviewNotes.isNotBlank(), onClick = {
                                scope.launch {
                                    saveBusy = true; saveMessage = ""
                                    try {
                                        firestore.saveDraft("interview-notes", "Interview practice notes", interviewNotes, when(lang){Lang.BN->"bn";Lang.HI->"hi";else->"en"})
                                        saveMessage = "Interview notes saved to your account."
                                    } catch (e: Exception) { saveMessage = e.localizedMessage ?: "Could not save notes." }
                                    saveBusy = false
                                }
                            }, modifier=Modifier.fillMaxWidth()) { Text(if(saveBusy) "Saving…" else "Save interview notes") }
                            if (saveMessage.isNotBlank()) Text(saveMessage, color=MaterialTheme.colorScheme.primary)
                            Text("Tip: Answer aloud in 60–90 seconds. These are practice questions, not a live AI interview.",
                                color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        "english" -> {
                            Text("Useful interview phrases", fontWeight=FontWeight.SemiBold)
                            listOf("Thank you for giving me this opportunity.","I am eager to learn and improve.","One of my strengths is problem-solving.","Could you please explain the role in more detail?").forEach { Text("• $it", Modifier.padding(vertical=8.dp)) }
                        }
                        else -> {
                            Text("Start with your interests, current skills and education. Choose one target role, review real job descriptions, then build a small project that demonstrates your ability.")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolCard(icon:String, title:String, desc:String, onClick:()->Unit) {
    Card(onClick=onClick, modifier=Modifier.fillMaxWidth().padding(vertical=6.dp),
        shape=RoundedCornerShape(18.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
        Row(Modifier.padding(16.dp), horizontalArrangement=Arrangement.spacedBy(14.dp)) {
            Text(icon, style=MaterialTheme.typography.headlineMedium)
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight=FontWeight.Bold)
                Text(desc, style=MaterialTheme.typography.bodySmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("›", style=MaterialTheme.typography.headlineMedium, color=MaterialTheme.colorScheme.primary)
        }
    }
}
