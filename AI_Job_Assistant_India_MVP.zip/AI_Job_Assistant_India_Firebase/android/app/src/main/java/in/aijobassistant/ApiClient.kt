package in.aijobassistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Authenticated backend client example.
 * Configure BASE_URL with your HTTPS backend URL before release.
 * Never place the AI provider key in this Android app.
 */
class ApiClient(
    private val baseUrl: String
) {
    suspend fun generate(
        idToken: String,
        task: String,
        language: String,
        input: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(task in setOf("resume", "cover-letter", "interview-feedback"))
            require(language in setOf("en", "bn", "hi"))
            require(input.length in 5..8000)

            val connection = (URL("$baseUrl/v1/generate").openConnection() as HttpURLConnection)
            try {
                connection.requestMethod = "POST"
                connection.connectTimeout = 15000
                connection.readTimeout = 35000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("Authorization", "Bearer $idToken")
                val body = JSONObject()
                    .put("task", task)
                    .put("language", language)
                    .put("input", input)
                    .toString()
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                if (code !in 200..299) {
                    throw IllegalStateException(json.optString("error", "Request failed ($code)"))
                }
                json.getString("text")
            } finally {
                connection.disconnect()
            }
        }
    }
}
