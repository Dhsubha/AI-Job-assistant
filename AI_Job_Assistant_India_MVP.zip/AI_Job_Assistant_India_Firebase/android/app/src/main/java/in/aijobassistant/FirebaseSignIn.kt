package in.aijobassistant

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.tasks.await

/**
 * Firebase Authentication: anonymous guest sign-in and Google sign-in
 * using Android Credential Manager. The web/server OAuth client ID is
 * supplied by Firebase in R.string.default_web_client_id after google-services setup.
 */
class FirebaseSignIn(private val context: Context) {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val credentialManager = CredentialManager.create(context)

    suspend fun continueAsGuest(): FirebaseUser {
        return auth.signInAnonymously().await().user
            ?: error("Guest sign-in did not return a user.")
    }

    suspend fun signInWithGoogle(): FirebaseUser {
        val googleOption = GetGoogleIdOption.Builder()
            .setServerClientId(context.getString(R.string.default_web_client_id))
            .setFilterByAuthorizedAccounts(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleOption)
            .build()

        val result = credentialManager.getCredential(context, request)
        val credential = result.credential
        if (credential !is CustomCredential ||
            credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            error("Google sign-in returned an unsupported credential.")
        }

        val googleToken = try {
            GoogleIdTokenCredential.createFrom(credential.data).idToken
        } catch (e: GoogleIdTokenParsingException) {
            error("Could not read the Google sign-in token.")
        }

        val firebaseCredential = GoogleAuthProvider.getCredential(googleToken, null)
        return auth.signInWithCredential(firebaseCredential).await().user
            ?: error("Google sign-in did not return a Firebase user.")
    }

    /**
     * Upgrade an anonymous account to Google while preserving its Firebase UID.
     * Call this from an explicit "Save my account" action while currently a guest.
     */
    suspend fun linkGuestToGoogle(): FirebaseUser {
        val current = auth.currentUser ?: error("No signed-in user.")
        if (!current.isAnonymous) return signInWithGoogle()

        val googleOption = GetGoogleIdOption.Builder()
            .setServerClientId(context.getString(R.string.default_web_client_id))
            .setFilterByAuthorizedAccounts(false)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(googleOption).build()
        val result = credentialManager.getCredential(context, request)
        val credential = result.credential as? CustomCredential
            ?: error("Unsupported Google credential.")
        if (credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            error("Unsupported Google credential type.")
        }
        val token = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val firebaseCredential = GoogleAuthProvider.getCredential(token, null)
        return current.linkWithCredential(firebaseCredential).await().user
            ?: error("Could not link Google account.")
    }

    fun currentUser(): FirebaseUser? = auth.currentUser
    fun signOut() = auth.signOut()
}
