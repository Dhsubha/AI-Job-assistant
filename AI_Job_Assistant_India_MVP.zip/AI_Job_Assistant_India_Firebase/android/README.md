# Android app

Open this `android/` folder in Android Studio. The project uses Kotlin, Jetpack Compose, Firebase Authentication and Cloud Firestore.

Package: `in.aijobassistant`  
Firebase project: `gen-lang-client-0393857895`

See the repository-root `README.md` and `docs/FIREBASE_PROJECT_SETUP.md` for Firebase setup. The supplied `app/google-services.json` is matched to this package, but Google sign-in still needs the signing certificate SHA fingerprints registered in Firebase.

This MVP uses local text templates for resume and cover-letter generation. Live AI is not connected, and no APK has been built or device-tested in this workspace.
